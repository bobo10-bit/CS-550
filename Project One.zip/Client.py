import socket

# Create socket
client = socket.socket()
# Set a 5 sec conection timeout
client.settimeout(5)

try:
    # Connect to the server by port 3306
    client.connect(("127.0.0.1", 3306))
    print("Connection successful")
except OSError:
    # Print error if the connection failed
    print("Connection failed")
finally:
    # Close the client socket
    client.close()






