import socket

# Create the socket
server = socket.socket()
# Listen to port 3306 for connections
server.bind(("0.0.0.0", 3306))
server.listen()

print("Server listening on port 3306")

try:
    # Wait for the client to connect
    connection, address = server.accept()
    print("Client connected successfully")
    # Close the connection
    connection.close()
except OSError:
    # Print error if there is a connection error
    print("Connection failed")
finally:
    # Close the server socket
    server.close()



